package com.pages.BookMyShow;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.Base.BaseTestClass;

public class DisplaySportsActivities extends BaseTestClass {
	
	static By city=By.cssSelector("img[alt='CHEN']");
	static By sport=By.xpath("//a[text()='Sports']");
	static By name=By.className("iGFUdZ");
    static By priceSelection= By.xpath("(//div[normalize-space()='Price'])[1]");
	static By zeroToFivehundred = By.xpath("(//div[contains(text(),'0 - 500')])[2]");
	static By thisWeekend = By.xpath("//*[@id=\"super-container\"]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[2]/div[3]/div[2]/div");

	public static void sports() throws InterruptedException, IOException {

		driver.findElement(city).click();
		Thread.sleep(5000);
		driver.findElement(sport).click();

		Thread.sleep(5000);

		//Thread.sleep(5000);
		//selecting price 0-500
//		driver.findElement(priceSelection).click();
//
//		Thread.sleep(10000);
//		driver.findElement(zeroToFivehundred).click();
//		Thread.sleep(10000);
		//Selecting This Weekend
		driver.findElement(thisWeekend).click();
		
		MakeBorder(driver.findElement(sport));Thread.sleep(1000);TakeScreenshot("SportsPage");
		UndoBorder(driver.findElement(sport));

		List<WebElement> names=driver.findElements(name);
		System.out.println("Sports Details:\n============================================");
		for(int j=0;j<names.size();++j){
			System.out.println(names.get(j).getText());
		}
		System.out.println("============================================\n\n");
		

		Thread.sleep(3000);
	}
	
	
}
