package com.pages.BookMyShow;

import java.io.IOException;
//import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;

import com.Base.BaseTestClass;

public class DisplayError extends BaseTestClass{

	static By sign=By.xpath("//div[text()='Sign in']");
	static By google=By.xpath("//*[@id=\"modal-root\"]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div/div");
	static By email=By.xpath("//*[@id=\"identifierId\"]");
	static By next=By.xpath("//span[text()='Next']");
	static By error1=By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/c-wiz[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/span[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]");
  
		public static void signin(String invalidEmail) throws InterruptedException, IOException {

		 Thread.sleep(10000);

			driver.findElement(sign).click();
			Thread.sleep(2000);

			//String mainWindow=driver.getWindowHandle();
			String parent = driver.getWindowHandle();
			driver.findElement(google).click();
			
//			Set<String> set =driver.getWindowHandles();
//			Iterator<String> itr= set.iterator();
//			
//			while(itr.hasNext()){
//				String childWindow=itr.next();
//				if(!mainWindow.equals(childWindow)){
//					// for switching to the child window 
//					driver.switchTo().window(childWindow);
			
			Set<String> winHandles = driver.getWindowHandles();
			for (String handle : winHandles) {
				if (!handle.equals(parent)) {
					driver.switchTo().window(handle);
				}
			}
					Thread.sleep(2000);

					driver.findElement(email).sendKeys(invalidEmail);
					driver.findElement(next).click();
					Thread.sleep(10000);
					//capture the error message 
					String error=driver.findElement(error1).getText();
					System.out.println("\nError is:\n====================================\n"+error+"\n====================================");
					MakeBorder(driver.findElement(error1));Thread.sleep(1000);TakeScreenshot("SignInPage");
			
					driver.quit();
				
			
			Thread.sleep(3000);
		}
	
}
