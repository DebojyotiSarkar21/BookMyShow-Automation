package com.pages.BookMyShow;

import java.io.IOException;

import org.openqa.selenium.By;

import com.Base.BaseTestClass;

public class DisplayLanguages extends BaseTestClass {
	
	static By movies=By.xpath("//a[text()='Movies']");
	static By lang=By.xpath("//*[@id=\"super-container\"]/div[2]/div[3]/div[1]/div[1]/div[2]/div[1]/div[2]");
	
	 
		public static void movie() throws InterruptedException, IOException {

		 Thread.sleep(10000);

		 driver.findElement(movies).click();
		 	
		 	MakeBorder(driver.findElement(movies));Thread.sleep(1000);TakeScreenshot("MoviesPage");
		 	UndoBorder(driver.findElement(movies));

			System.out.println("Languages:\n============================================");
			Thread.sleep(10000);
			String languages=driver.findElement(lang).getText();
			System.out.println(languages);
			System.out.println("============================================\n\n");
//			
			Thread.sleep(3000);
		}

}
