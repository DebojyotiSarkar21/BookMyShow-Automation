package com.pages.BookMyShow;


import com.Base.BaseTestClass;

public class LoadBookMyShow extends BaseTestClass {
	
	
	public static void openUrl(String baseUrl) throws InterruptedException
	{
		driver.get(baseUrl);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		System.out.println("The current URL: "+driver.getCurrentUrl());
	}

}